from interface import login
def test_sign_in():
    result = login.sign_in("Lalit", "admin")
    assert result

def test_sign_in_fail():
    result = login.sign_in("Lalit", "admin1")
    assert not result

def test_sign_in_fail_2():
    result = login.sign_in("Lalit1", "admin")
    assert not result

def test_get_username():
    result = login.get_username("Lalit")
    assert result == "Lalit"

