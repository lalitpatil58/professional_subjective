import pandas as pd
import streamlit as st

class login:
    def __init__(self):
        self.username = None
        self.password = None
        
    def sign_in(self):
        st.title("Login")
        self.username = st.text_input("Username")
        self.password = st.text_input("Password", type="password")
        if st.button("Login"):
            if self.username in ["admin", "Lalit"] and self.password == "admin":
                st.success("Login successful!")
                return True
            else:
                st.error("Invalid username or password")
                return False
        return False
    
    def get_username(self):
        return self.username
    
if __name__ == "__main__":
    tab1, tab2, tab3 = st.tabs(["LOGIN", "CART", "INVOICE"])
    css = '''<style>
            .stTabs [data-baseweb="tab-list"] button [data-testid="stMarkdownContainer"] p {
            font-size:1.5rem;}
             </style>'''
    st.markdown(css, unsafe_allow_html=True)

    login = login()
    with tab1:
        if login.sign_in():
            with tab2:
                st.write(f"Welcome ---- {login.get_username()}")
    with tab2:
        st.title("Cart")
        items = []
        sum = 0
        message = """Please add items in a cart.

                Item                                                   Price  """
        st.info(message)
        col1, col2, col3 = st.columns(3)
        # col1.write("Please add the items in a cart")
        user_df = pd.read_csv(r"D:/Persistent/Y2024/GenAI_POC/Vector_Database/customer.csv")
        product_df = pd.read_csv(r"D:/Persistent/Y2024/GenAI_POC/Vector_Database/product_dataset.csv", encoding='unicode_escape')
        product_df = product_df.dropna()
        product_df = product_df.drop_duplicates()
        product_df["item_price"] = product_df["item_price"].astype("float")

        for key, value in product_df.iterrows():
            with col1:
                item = st.checkbox(value["product"])
                if item:
                    items.append({"Product":value["product"],"Price":float(value["item_price"])})
            with col3:
                st.write(str(value["item_price"])+ " " + "Rs", key="disabled" + str(key))
    with tab3:
        st.title("           INVOICE                    ")
        col1, col2 = st.columns(2)
        with col1:
            if st.button("Cart Total"):
                st.info("Cart Items")
                item, price = st.columns(2)
                for item in items:
                    st.write(str(item["Product"])+ "________"+ str(item["Price"]))
                for item in items:
                    price = item["Price"]
                    sum = sum + price
                customer_name = login.get_username()
                customer_full_name = user_df[user_df["User"] == customer_name]["Full_Name"].values[0]
                shipping_address = user_df[user_df["User"] == customer_name]["Shipping_Address"].values[0]
                st.info("Customer Details")
                st.write("Customer Name: " + " " + customer_full_name)
                st.write("Shipping Adress: " + " " + shipping_address)
                with col2:
                    billing_address = user_df[user_df["User"] == customer_name]["Billing_Address"].values[0]
                    mobile = user_df[user_df["User"] == customer_name]["Mobile"].values[0]
                    st.write("")
                    st.write("")
                    st.write("")
                    st.write("Billing Adress: " + " " + billing_address)
                    st.write("Mobile: " + " " + str(mobile))
                    st.write("___________________________________________")
                    st.info("Total: " + " " + str(round(sum, 2)) + " " + "Rs")
                    
                    


    


            



        
   
    